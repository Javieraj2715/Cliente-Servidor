
package Avance01;


public interface Ventas {
    void registrarVentas();
    void generarFactura();
    void calcularValorVentas();
}
