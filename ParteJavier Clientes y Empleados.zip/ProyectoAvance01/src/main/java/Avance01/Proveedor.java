
package Avance01;


public class Proveedor extends Persona {
    
    protected String direccion;
    protected String correoElectronico;

    public Proveedor(String direccion, String correoElectronico, String nombre, String id, String numTelefono,String correo) {
        super(nombre, id, numTelefono,correo);
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
    }
    
    @Override
    public String mostrarDatos(){
        return "0";
}
}
