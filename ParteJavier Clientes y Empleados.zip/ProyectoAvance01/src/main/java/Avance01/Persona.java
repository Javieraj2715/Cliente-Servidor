
package Avance01;

public abstract class Persona {
    protected String nombre;
    protected String id;
    protected String numTelefono;
    protected String correo;
    

    public Persona(String nombre, String id, String numTelefono,String correo) {
        this.nombre = nombre;
        this.id = id;
        this.numTelefono = numTelefono;
        this.correo = correo;
        
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    
    
    
    
    public abstract String mostrarDatos();
}
