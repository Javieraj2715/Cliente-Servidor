
package Avance01;


public interface CategoriaProducto {
    void agregarProducto();
    void tipoProducto();
    
}
