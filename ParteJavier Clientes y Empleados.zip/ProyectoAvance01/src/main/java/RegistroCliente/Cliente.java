
package RegistroCliente;

import Avance01.Persona;


public class Cliente extends Persona {

    protected int productosComprados;

    public Cliente(String nombre, String id, String numTelefono,String correo) {
        super(nombre, id, numTelefono,correo);
    }

    public int getProductosComprados() {
        return productosComprados;
    }

    public void setProductosComprados(int productosComprados) {
        this.productosComprados = productosComprados;
    }

    

    

    

    
    
    
    

    
    
    
    public void historialCompras(){
        
    }

    @Override
    public String mostrarDatos() {
        return "0";
    }
}
