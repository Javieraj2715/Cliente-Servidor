
package RegistroEmpleado;

import Avance01.Persona;


public class Empleado extends Persona {
    
    protected int salario;
    

    public Empleado( String nombre, String id,String correo,String numero) {
        super(nombre,id,correo, numero);
        
    }

    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
    
    
    
    @Override
    public String mostrarDatos(){
        return "0";
    }
    
}
